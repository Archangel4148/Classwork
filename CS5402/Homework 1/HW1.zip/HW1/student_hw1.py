import numpy as np
import matplotlib.pyplot as plt
# DO NOT import any other libraries.


def confusion_matrix_metrics(conf_mat):
    """
    Compute evaluation metrics from a confusion matrix.

    Parameters
    ----------
    conf_mat : np.ndarray of shape (K, K)
        Confusion matrix where conf_mat[i, j] is the number of
        samples with true label i predicted as label j.

    Returns
    -------
    metrics : np.ndarray of shape (K, 4)
        Each row corresponds to one class.
        Columns are:
        [accuracy, recall, precision, f1_score]
    """

    # TODO:
    # Your implementation.



    

    return metrics




def plot_roc_curve(y_true, y_score, num_thresholds=100):
    """
    Plot ROC curve from ground-truth labels and predicted probabilities.

    Parameters
    ----------
    y_true : array-like of shape (n_samples,)
        Ground truth binary labels (0 or 1)

    y_score : array-like of shape (n_samples,)
        Predicted probabilities for the input

    num_thresholds : int
        Number of thresholds to evaluate (default=100)

    Returns
    -------
    fpr : np.ndarray
        False Positive Rates

    tpr : np.ndarray
        True Positive Rates
    """


    tpr_list = []
    fpr_list = []

    # TODO:
    # Your implementation.





    # Plot ROC curve
    plt.figure()
    plt.plot(fpr_list, tpr_list, label="ROC Curve")
    plt.plot([0, 1], [0, 1], linestyle="--", label="Random Guess")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")
    plt.legend()
    plt.show()

    return np.array(fpr_list), np.array(tpr_list)